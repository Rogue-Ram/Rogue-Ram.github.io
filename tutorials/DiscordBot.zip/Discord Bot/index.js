const Discord = require('discord.js');
const botclient = new Discord.Client();
const prefix = '!';
botclient.once('ready',()=> {
    botclient.user.setActivity('!help',{type: ""})
    console.log('Bot Enabled');
})
botclient.login('ODYyOTA2ODE3ODY3ODA4NzY4.YOfKmQ.bIWz2rVeii21JHl5p5SK0YOa2DU')

botclient.on('message',msg => {
if (msg.author.bot) return;
if (msg.guild === null){
    console.log('Someone messaged me via dms!')
    msg.author.send('You can not message me via DMs!');
    return
}
if (!msg.content.startsWith(prefix)) return;
const cmdbody = msg.content.slice(prefix.length);
const args = cmdbody.split(' ');
const command = args.shift().toLocaleLowerCase();
const muser = msg.mentions.users.first();
if (command === "test")
{
msg.reply("Hello there")
}
if (command === "help")
{
msg.reply("You can find all commands here: https://example.com")
}
if (command === "kick")
{
if(!msg.member.roles.cache.some(role => role.name === 'Admin')) {
    msg.reply('You do not have permission to Kick users from the guild!')
    return
}
if(!muser){
    msg.reply('You did not mention a user to Kick!')
}
const sender = msg.member
const member = msg.guild.member(muser)
if(member){
    member.kick(`Kicked by ${sender}`).then(() => {
        msg.reply("Done")
    })
}
}

if (command === "ban")
{
if(!msg.member.roles.cache.some(role => role.name === 'Admin')) {
    msg.reply('You do not have permission to Ban users from the guild!')
    return
}
if(!muser){
    msg.reply('You did not mention a user to Ban!')
}
const sender = msg.member
const member = msg.guild.member(muser)
if(member){
    member.ban({reason: `Banned by ${sender}`}).then(() => {
        msg.reply("Done")
    })
}
}

});